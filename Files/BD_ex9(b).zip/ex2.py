from pyspark import SparkContext
import pandas as pd
from pyspark.sql import Row

# Initiate Session
sc = SparkContext("local", "Ex2")

def q1():
    def parallel(x):
        avg = sum(x)/len(x)
        return avg

    # Read CSV files
    friends = sc.textFile("friends_test.csv")
    friends = friends.map(lambda line: line.split(","))
    friends = friends.map(lambda line: (int(line[-2]), int(line[-1])))
    x = friends.groupByKey().mapValues(parallel).collect()
    print(*x, sep="\n")


def q2():
    def order(x):
        x = x.split(",")
        return tuple(x)
    
    # Read CSV files
    temp = sc.textFile("temp.csv")
    temp = temp.map(order)
    filtered = temp.filter(lambda x: "TMIN" != x[1])
    itemid = filtered.map(lambda x: (x[0], x[-1]))
    itemid = itemid.reduceByKey(lambda x,y: min(x,y)).collect()
    stationid = filtered.map(lambda x: (x[1], x[-1]))
    stationid = stationid.reduceByKey(lambda x,y: min(x,y)).collect()
    
    print("######### ITEMID ###########")
    print(*itemid, sep="\n\n")
    print("######### STATIONID ###########")
    print(*stationid, sep="\n\n")
    
    overall = filtered.map(lambda x: (0, x[-1]))
    overall = overall.reduceByKey(lambda x,y: min(x,y)).collect()
    print("######### OVERALL ###########")
    print(overall, end="\n\n")
    
    print("######### TMAX ###########")
    filtered = temp.filter(lambda x: "TMAX" in x[2])
    maximum = filtered.map(lambda x: (x[-2], x[-1]))
    maximum = maximum.reduceByKey(lambda x,y: max(x,y)).collect()
    print(maximum, end="\n\n")
    
    
if __name__ == "__main__":
    q2()