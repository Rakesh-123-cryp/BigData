from pyspark import SparkConf, SparkContext
import collections

conf = SparkConf().setMaster("local").setAppName("movielens")
sc = SparkContext(conf = conf)

lines = sc.textFile("movielens.txt")
ratings = lines.map(lambda x: x.split()[2])
result = ratings.countByValue()

for key, value in result.items():
    print(key,value)
