#!/usr/bin/env python
import sys

current_year = None
min_temp = float('inf')
max_temp = float('-inf')

# Input comes from standard input (stdin)
for line in sys.stdin:
    year, temperature = line.strip().split('\t')
    temperature = float(temperature)

    if current_year == year:
        # Update min and max temperatures
        if temperature < min_temp:
            min_temp = temperature
        if temperature > max_temp:
            max_temp = temperature
    else:
        # Output the result for the previous year
        if current_year:
            print(f"{current_year}\tMin:{min_temp}\tMax:{max_temp}")
        
        # Update year and reset min and max temperatures
        current_year = year
        min_temp = temperature
        max_temp = temperature

# Output the result for the last year
if current_year:
    print(f"{current_year}\tMin:{min_temp}\tMax:{max_temp}")
