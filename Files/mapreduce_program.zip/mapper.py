#!/usr/bin/env python
import sys

# Input comes from standard input (stdin)
for line in sys.stdin:
    data = line.strip().split()
    
    # Assuming data[0] is year and data[1] is temperature
    if len(data) != 2:
        continue
    
    year, temperature = data
    try:
        temperature = float(temperature)
        # Output year as the key and temperature as the value
        print(f"{year}\t{temperature}")
    except ValueError:
        continue
